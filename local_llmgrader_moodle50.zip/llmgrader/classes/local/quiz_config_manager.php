<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Quiz configuration manager for LLM Grader plugin.
 *
 * @package   local_llmgrader
 * @copyright 2025
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_llmgrader\local;

// MOODLE_INTERNAL check removed - class is autoloaded

/**
 * Quiz configuration manager class.
 *
 * Handles CRUD operations for quiz-level LLM Grader configuration.
 */
class quiz_config_manager {

    /**
     * Get or create the configuration record for a quiz.
     *
     * @param int $quizid Quiz ID.
     * @param int $courseid Course ID (required for creation).
     * @return object Configuration record (always exists after this call).
     */
    public static function get_or_create(int $quizid, int $courseid): object {
        global $DB;

        $config = self::get($quizid);
        if ($config) {
            return $config;
        }

        $now = time();
        $record = (object)[
            'quizid' => $quizid,
            'courseid' => $courseid,
            'enabled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
        ];

        $record->id = $DB->insert_record('local_llmgrader_quiz_config', $record);
        config_provider::clear_cache();

        return $record;
    }

    /**
     * Get the configuration record for a quiz.
     *
     * @param int $quizid Quiz ID.
     * @return object|null Configuration record or null if not configured.
     */
    public static function get(int $quizid): ?object {
        global $DB;

        try {
            $record = $DB->get_record('local_llmgrader_quiz_config', ['quizid' => $quizid]);
            return $record ?: null;
        } catch (\dml_exception $e) {
            return null;
        }
    }

    /**
     * Update the configuration for a quiz.
     *
     * @param int $quizid Quiz ID.
     * @param object $data Configuration data to save.
     * @return object Updated configuration record.
     */
    public static function update(int $quizid, object $data): object {
        global $DB;

        $config = self::get($quizid);

        if (!$config) {
            $data->quizid = $quizid;
            $data->timecreated = time();
            $data->timemodified = time();
            $config = (object)[
                'id' => $DB->insert_record('local_llmgrader_quiz_config', $data),
            ];
        } else {
            $data->id = $config->id;
            $data->quizid = $quizid;
            $data->timemodified = time();
            $DB->update_record('local_llmgrader_quiz_config', $data);
            $config = self::get($quizid);
        }

        config_provider::clear_cache();

        return $config;
    }

    /**
     * Delete the configuration for a quiz.
     *
     * @param int $quizid Quiz ID.
     */
    public static function delete(int $quizid): void {
        global $DB;

        $DB->delete_records('local_llmgrader_quiz_config', ['quizid' => $quizid]);
        config_provider::clear_cache();
    }

    /**
     * Check if a quiz has non-default configuration.
     *
     * @param int $quizid Quiz ID.
     * @return bool True if the quiz has explicit overrides.
     */
    public static function has_config(int $quizid): bool {
        $config = self::get($quizid);
        return $config !== null;
    }

    /**
     * Validate that a quiz belongs to a specific course before saving config.
     *
     * @param int $quizid Quiz ID.
     * @param int $expectedcourseid Expected course ID.
     * @return bool True if the quiz belongs to the expected course.
     */
    public static function validate_course(int $quizid, int $expectedcourseid): bool {
        global $DB;

        try {
            $quiz = $DB->get_record('quiz', ['id' => $quizid], 'course', MUST_EXIST);
            return (int)$quiz->course == $expectedcourseid;
        } catch (\dml_exception $e) {
            return false;
        }
    }

    /**
     * Build a data object from form submission.
     *
     * @param \stdClass $formdata Form submitted data.
     * @return object Sanitized configuration data.
     */
    public static function from_form_data(\stdClass $formdata): object {
        $data = new \stdClass();

        $data->enabled = !empty($formdata->llmgrader_enabled) ? 1 : 0;
        $data->api_endpoint = !empty($formdata->llmgrader_api_endpoint) ? trim($formdata->llmgrader_api_endpoint) : null;
        $data->api_key = !empty($formdata->llmgrader_api_key) ? trim($formdata->llmgrader_api_key) : null;
        $data->model = !empty($formdata->llmgrader_model) ? trim($formdata->llmgrader_model) : null;
        $data->temperature = !empty($formdata->llmgrader_temperature) ? floatval($formdata->llmgrader_temperature) : null;
        $data->max_tokens = !empty($formdata->llmgrader_max_tokens) ? intval($formdata->llmgrader_max_tokens) : null;
        $data->http_timeout = !empty($formdata->llmgrader_http_timeout) ? intval($formdata->llmgrader_http_timeout) : null;
        $data->system_prompt = null;
        $promptvalue = $formdata->llmgrader_system_prompt_editor ?? $formdata->llmgrader_system_prompt ?? '';
        if (is_array($promptvalue)) {
            $promptvalue = $promptvalue['text'] ?? '';
        }
        if ($promptvalue !== null && trim((string)$promptvalue) !== '') {
            $data->system_prompt = trim((string)$promptvalue);
        }
        $data->feedback_language = !empty($formdata->llmgrader_feedback_language) ? trim($formdata->llmgrader_feedback_language) : null;
        $data->retry_enabled = !empty($formdata->llmgrader_retry_enabled) ? 1 : 0;
        $data->max_retries = !empty($formdata->llmgrader_max_retries) ? intval($formdata->llmgrader_max_retries) : null;
        $data->base_retry_delay = !empty($formdata->llmgrader_base_retry_delay) ? intval($formdata->llmgrader_base_retry_delay) : null;
        $data->max_backoff_delay = !empty($formdata->llmgrader_max_backoff_delay) ? intval($formdata->llmgrader_max_backoff_delay) : null;

        // Null out empty strings.
        foreach (['api_endpoint', 'api_key', 'model', 'system_prompt', 'feedback_language'] as $field) {
            if ($data->$field === '') {
                $data->$field = null;
            }
        }

        // Null out zero values for numeric fields.
        foreach (['max_tokens', 'http_timeout', 'max_retries', 'base_retry_delay', 'max_backoff_delay'] as $field) {
            if ($data->$field === 0) {
                $data->$field = null;
            }
        }

        return $data;
    }
}
